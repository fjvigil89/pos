<?php
$lang['error_no_permission_module']='Você não tem permissão para acessar o módulo chamado';
$lang['error_unknown']='desconhecido';
$Lang['error_sales_consolidation'] = 'Ocorreu um erro ao processar este relatório, verifique se a caixa é fechada e tente novamente';
?>