<?php
$lang['item_kits_name'] = 'Nome Conjunto';
$lang['item_kits_description'] = 'Descrição Conjunto';
$lang['item_kits_no_item_kits_to_display'] = 'Nunhum conjunto para mostrar';
$lang['item_kits_update'] = 'Atualizar conjunto';
$lang['item_kits_new'] = 'Novo conjunto';
$lang['item_kits_none_selected'] = "Você não selecionou nenhum conjunto";
$lang['item_kits_info'] = 'Informação conjunto';
$lang['item_kits_successful_adding'] = 'Você adicionou com sucesso o conjunto';
$lang['item_kits_successful_updating'] = 'You have successfully updated Item Kit';
$lang['item_kits_error_adding_updating'] = 'Erro adicionar/ atualizar o conjunto';
$lang['item_kits_successful_deleted'] = 'Deletado com sucesso';
$lang['item_kits_confirm_delete'] = 'Tem certeza que deseja deletar os conjuntos selecionados?';
$lang['item_kits_one_or_multiple'] = 'Conjunto(s)';
$lang['item_kits_cannot_be_deleted'] = 'Não foi possivel deletar o conjunto(s)';
$lang['item_kits_add_item'] = 'Adiconar Produto';
$lang['item_kits_items'] = 'Produtos';
$lang['item_kits_item'] = 'Produtos';
$lang['item_kits_quantity'] = 'Quantidade';
$lang['item_kits_desc'] = 'Os conjuntos são compostos de um ou mais produtos para se ver como um grupo. Adicione o seu primeiro produto usando o campo abaixo.';
$lang['item_kits_items_added'] = 'Produtos adicionados';


$lang['item_kits_no_items_added'] = 'Você não adicionou nenhum produto para kit';
$lang['items_kits_name_help'] = 'Entre os produtos, um a um para montar o kit ';
$lang['items_item_number_help'] = 'Insira o kit de código de barras ';
$lang['items_product_id_help'] = 'Inserir o nome do kit de identificação ';
$lang['item_kits_name_help'] = 'Insira o nome do kit, é obrigatório';
$lang['items_category_help'] = 'Digite categoria kit é obrigatória ';
?>