<?php  
$lang['day_1'] = "Segunda-feira";
$lang['day_2'] = "Terça-Feira";
$lang['day_3'] = "Quarta-Feira";
$lang['day_4'] = "Quinta-Feira";
$lang['day_5'] = "Sexta-Feira";
$lang['day_6'] = "Sábado";
$lang['day_7'] = "Domingo";
?>