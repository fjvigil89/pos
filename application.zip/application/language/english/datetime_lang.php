<?php  
$lang['day_1'] = "Monday";
$lang['day_2'] = "Tuesday";
$lang['day_3'] = "Wednesday";
$lang['day_4'] = "Thursday";
$lang['day_5'] = "Friday";
$lang['day_6'] = "Saturday";
$lang['day_7'] = "Sunday";
?>