<?php
$lang['error_no_permission_module']='You do not have permission to access the module named';
$lang['error_unknown']='unknown';
$lang['error_sales_consolidation'] = 'Error sales consolidation';
$lang['error_no_permission_action']='!Error¡ No permission action';
$lang['error_access_receiving']='Error access receiving';
$lang['error_mount_blank']='!Error¡ Mount Blank';
?>