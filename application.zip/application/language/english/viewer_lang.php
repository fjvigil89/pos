<?php
$lang["viewer_carousel"]="Carousel";
$lang["viewer_and"]="and";
$lang["viewer_activate"]="Activate";
$lang["viewer_change_msg"]="Change message";
$lang["viewer_thanks_msg"]= "Thanks message";
$lang["viewer_transition_time"]="Transition time between images";
$lang["viewer_price_consultant"]="Price checker";
?>