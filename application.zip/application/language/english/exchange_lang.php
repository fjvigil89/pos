<?php 
$lang['change_item']	="Bank";
?>