<?php
$lang['descripcion'] = "Descripcion";

?>
