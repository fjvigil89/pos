<?php
$lang['offline_title'] = "Offline";
$lang['Offline_configuration'] = "Offline configuration";
$lang['Password_Login'] = "Password Login";
$lang['data_password_title'] = "Password Home Session Offline Mode";
$lang['password_mensaje'] = "This password is NOT for logging in to the pos, it is for logging into offline mode (without internet connection), it is recommended that the password is not equal to the POS";
$lang['time_sincronizacion'] = "DB synchronization time";
$lang['minute'] = "minute";
$lang['hours'] = "Hour(s)";
$lang['button_save'] = "Save";
?>