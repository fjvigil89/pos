<?php
$lang['offline_title'] = "Offline";
$lang['Offline_configuration'] = "Offline configuration";
$lang['Password_Login'] = "Password Login";
$lang['data_password_title'] = "Password Home Session Offline Mode";
$lang['password_mensaje'] = "This password is NOT for logging in to the pos Online, it is for logging into offline mode (without internet connection), it is recommended that the password is not equal to the POS";
$lang['time_sincronizacion'] = "DB synchronization time";
$lang['minute'] = "minute";
$lang['hours'] = "Hour(s)";
$lang['button_save'] = "Save";
$lang['data_password_title_again'] = "Confirm Password Home Session Offline Mode";
$lang['Password_Again'] = "Confirm Password";
$lang['Password_creation'] = "Steps Work Offline Mode.";
$lang['Password_creation_step_1'] = "Create the password (minimum 6 digits.)";
$lang['Password_creation_step_2'] = "Synchronize inventory.";
$lang['Password_creation_step_3'] = "Save this web address to access without internet: ";
?>