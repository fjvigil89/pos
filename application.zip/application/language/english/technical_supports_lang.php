<?php

$lang['technical_support_information']="Basic information";
?>