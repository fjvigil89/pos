<?php 
$lang["warehouse_pendiente"]="PENDING";
$lang["warehouse_rechazado"]="REJECTED";
$lang["warehouse_entregado"]="DELIVERED";

?>