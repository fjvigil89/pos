<?php
$lang['error_no_permission_module']='Vous n\'avez pas la permission requises pour accéder à ce module';//The good translation
$lang['error_unknown']='inconnue';
?>