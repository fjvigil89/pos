<?php
$lang['offline_title'] = "Offline";
$lang['Offline_configuration'] = "Configuración Offline";
$lang['Password_Login'] = "Contraseña Inicio Sesión";
$lang['data_password_title'] = "Contraseña Inicio Sesión Modo Offline";
$lang['password_mensaje'] = "Esta contraseña NO es para iniciar sesión en el pos Online, es para iniciar sesión en modo Offline (Sin conexión a internet), se recomienda que la contraseña no sea igual a la del POS";
$lang['time_sincronizacion'] = "Tiempo sincronización DB";
$lang['minute'] = "Minuto(s)";
$lang['hours'] = "Hora(s)";
$lang['button_save'] = "Guardar";
$lang['data_password_title_again'] = "Confirmar Contraseña Inicio Sesión Modo Offline";
$lang['Password_Again'] = "Confirmar contraseña";
$lang['Password_creation_step_1'] = "Crea la contaseña ( minimo 6 digitos.)";
$lang['Password_creation_step_2'] = "Sincronice el inventario.";
$lang['Password_creation_step_3'] = "Guarde esta dirección web para acceder sin internet: ";
?>