<?php
$lang['error_no_permission_module']='U heeft geen toestemming voor toegang tot de module met de naam';
$lang['error_unknown']='onbekend';
?>