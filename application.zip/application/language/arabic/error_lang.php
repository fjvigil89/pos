<?php
$lang['error_no_permission_module']='لم يكن لديك إذن للوصول إلى وحدة اسمه';
$lang['error_unknown']='غير معرف';
?>