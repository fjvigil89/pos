<?php
$lang['item_kits_name'] = 'اسم مجموعة المواد';
$lang['item_kits_description'] = 'شرح مجموعة المواد';
$lang['item_kits_no_item_kits_to_display'] = 'لا يوجد مجموعة مواد لعرضها';
$lang['item_kits_update'] = 'تعديل مجموعة المواد';
$lang['item_kits_new'] = 'اضافة مجموعة مواد';
$lang['item_kits_none_selected'] = "لن تختر اي مجموعة مواد";
$lang['item_kits_info'] = 'معلومات مجموعة المواد';
$lang['item_kits_successful_adding'] = 'تم اضافة مجموعة المواد بنجاح';
$lang['item_kits_successful_updating'] = 'تم تعديل مجموعة المواد بنجاح';
$lang['item_kits_error_adding_updating'] = 'خطأ في اضافة او تعديل مجموعة المواد';
$lang['item_kits_successful_deleted'] = 'تم الحذف بنجاح';
$lang['item_kits_confirm_delete'] = 'هل انت متأكد من حذف مجموعة المواد؟';
$lang['item_kits_one_or_multiple'] = 'مجموعات المواد';
$lang['item_kits_cannot_be_deleted'] = 'لا يمكن حذف المجموعات';
$lang['item_kits_add_item'] = 'اضافة ماده';
$lang['item_kits_items'] = 'المواد';
$lang['item_kits_item'] = 'ماده';
$lang['item_kits_quantity'] = 'الكمية';
$lang['item_kits_desc'] = 'مصنوعة أطقم البند يصل من 1 أو أكثر من البنود لنرى كمجموعة. إضافة البند الأول الخاص بك باستخدام الحقل التالي.';
$lang['item_kits_items_added'] = 'تم اضافة المواد';
?>