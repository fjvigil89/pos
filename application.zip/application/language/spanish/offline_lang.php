<?php
$lang['offline_title'] = "Offline";
$lang['Offline_configuration'] = "Configuración Offline";
$lang['Password_Login'] = "Contraseña Inicio Sesión";
$lang['data_password_title'] = "Contraseña Inicio Sesión Modo Offline";
$lang['password_mensaje'] = "Esta contraseña NO es para iniciar sesión en el pos, es para iniciar sesión en modo Offline (Sin conexión a internet), se recomienda que la contraseña no sea igual a la del POS";
$lang['time_sincronizacion'] = "Tiempo sincronización DB";
$lang['minute'] = "Minuto(s)";
$lang['hours'] = "Hora(s)";
$lang['button_save'] = "Guardar";
?>