<?php  
$lang['day_1'] = "Lunes";
$lang['day_2'] = "Martes";
$lang['day_3'] = "Miércoles";
$lang['day_4'] = "Jueves";
$lang['day_5'] = "Viernes";
$lang['day_6'] = "Sábado";
$lang['day_7'] = "Domingo";
?>