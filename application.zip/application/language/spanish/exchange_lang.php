<?php
$lang['change_item']	="Banco";
$lang['change_account_type']	="Tipo de cuenta";
$lang['change_account_number']	="Número de cuenta bancaria";
$lang['change_help_account_number']	="Verificar 20 dígitos";
$lang['change_help_account_holder']	="Ingrese Nombre del titular";
$lang['change_account_holder']	="Titular de la cuenta";
$lang['change_help_document_holder']	="Ingrese Número de documento";
$lang['change_help_value']	="Ingrese cantida $";
$lang['change_document']	="Documento";
$lang['change_value']	="Valor en peso";
?>