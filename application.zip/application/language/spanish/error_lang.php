<?php
$lang['error_no_permission_module']='No tienes permiso para accesar el módulo llamado';
$lang['error_unknown']='desconocido';
$lang['error_sales_consolidation'] = 'Ocurrió un error al procesar este reporte, verifique que la caja se encuentre cerrada e intente nuevamente';
$lang['error_no_permission_action']='!Error¡ No tienes permiso para esta acción';
$lang['error_access_receiving']='No tiene permiso para eliminar Compras';
$lang['error_mount_blank']='!Error¡ Monto en blanco';
?>