<?php 
$lang["warehouse_pendiente"]="PENDIENTE";
$lang["warehouse_rechazado"]="RECHAZADO";
$lang["warehouse_entregado"]="ENTREGADO";
$lang["warehouse_rango_fecha"]="Rango de fecha";
$lang["warehouse_ID"]="ID";
$lang["warehouse_numero"]="Orden";
$lang["warehouse_fecha"]="Fecha";
$lang["warehouse_estado"]="Estado";
$lang["warehouse_cantidad_item"]="Artículos";
$lang["warehouse_detalles"]="Detalles";

?>