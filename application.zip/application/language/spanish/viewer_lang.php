<?php
$lang["viewer_carousel"]="Carrusel";
$lang["viewer_and"]="y";
$lang["viewer_activate"]="Activar";
$lang["viewer_change_msg"]="Mensaje de cambio";
$lang["viewer_thanks_msg"]= "Mensaje de gracias";
$lang["viewer_transition_time"]="Tiempo de transición entre las imágenes";
$lang["viewer_price_consultant"]="Verificador de precios";

?>