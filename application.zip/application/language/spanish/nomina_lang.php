<?php
$lang['nomina_descripcion'] = "Descripción";
$lang['nomina_monto'] = "Monto";
$lang['nomina_porcentaje'] = "Porcentaje";
$lang['nomina_fecha'] = "Fecha";
$lang['nomina_nueva_asignacion'] = "Nueva asiganacón";
$lang['nomina_nueva_deduccion'] = "Nueva deducción";
$lang['nomina_opciones'] = "Opciones";
$lang['nomina_informacion'] = "Información de Nómina";
$lang['nomina_deduccion'] = "Deducciones";
$lang['nomina_asignacion'] = "Asignaciones";
$lang['nomina_cancelar'] = "Calcelar";
$lang['nomina_informacion_dedu_asig'] = "Información";
$lang['nomina_error_guardar'] = "Error al guardar los datos";
$lang['nomina_exito_guardar'] = "Datos guardados con exitos";
$lang['nomina_eliminado'] = "Registro eliminado";
$lang['nomina_no_eliminado'] = "Registro no eliminado";
$lang['nomina_actualizado'] = "Datos actualizado";
$lang['nomina_agregado'] = "Datos agregados";
$lang['nomina_eliminar_registro'] = "¿Desea eliminar el registro?";
$lang['nomina_Fecha'] = "Fecha";
$lang['nomina_periodo_desde'] = "Período desde";
$lang['nomina_periodo_hasta'] = "Período hasta";
$lang['nomina_numero'] = "Número";


?>
