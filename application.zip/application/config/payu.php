<?php

$config['payu_api_key']       = 'ahif0bpa3qv1srhfnkp99h40';
$config['payu_merchantId']    = '513362';
$config['payu_accountId']     = '514695';
$config['payu_gateway_url']   = 'https://gateway.payulatam.com/ppp-web-gateway/';
$config['payu_currency']      = 'USD';
$config['one_month']          = '29';
$config['two_months']         = '58';
$config['three_months']       = '78';
$config['six_months']         = '139';
$config['one_year']           = '479';
$config['renovation']         = '143';
$config['register_value']           = '5';

$config['payu_test']          = 0;
