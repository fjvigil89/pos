<?php $this->load->view("partial/header");?>
<?php $this->load->view('changes_house/form');?>
<?php $this->load->view("partial/footer");?>
