<?php $this->load->view("partial/header"); ?>

<div>
<h3>Ocurrió un error al procesar el pago...  <br><?= $error_message?></h3>
</div>

<?php $this->load->view("partial/footer"); ?>