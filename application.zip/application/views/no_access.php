<div class="text-center">

    <strong>
        <?php echo lang('error_no_permission_module').' '.$module_name; ?> 
     </strong>
</div>
