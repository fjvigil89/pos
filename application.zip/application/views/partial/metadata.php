   <script src="<?php echo base_url();?>js/validator.js" type="text/javascript"></script>
   <script src="<?php echo base_url();?>js/ladda.js" type="text/javascript"></script>
   <script src="<?php echo base_url();?>js/spin.js" type="text/javascript"></script> <script src="<?php echo base_url();?>js/validator.js" type="text/javascript"></script>
   <script src="<?php echo base_url();?>js/jquery.dataTables.js" type="text/javascript"></script>
   <script src="<?php echo base_url();?>js/dataTables.tableTools.js" type="text/javascript"></script>