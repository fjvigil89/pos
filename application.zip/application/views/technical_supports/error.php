<?php $this->load->view("partial/header"); ?>

<div>
<h3><?=$error?></h3>
</div>

<?php $this->load->view("partial/footer"); ?>