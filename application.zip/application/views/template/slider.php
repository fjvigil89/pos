<section id="slider" class="slider-parallax hidden-xs hidden-sm" style="background-color: #222;">
	<div id="oc-slider" class="owl-carousel carousel-widget" data-margin="0" data-items="1" data-pagi="false" data-loop="true" data-animate-in="rollIn" data-speed="450" data-animate-out="rollOut" data-autoplay="5000">
		<a href="#"><img src="<?php echo  $data['base_url']; ?>/assets/template/images/slider/slider-1.jpg" alt="Slider"></a>
		<a href="#"><img src="<?php echo  $data['base_url']; ?>/assets/template/images/slider/slider-2.jpg" alt="Slider"></a>
		<a href="#"><img src="<?php echo  $data['base_url']; ?>/assets/template/images/slider/slider-3.jpg" alt="Slider"></a>
	</div>
</section>