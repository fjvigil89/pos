<div id="top-bar">
		<div class="container clearfix">
			<div class="col_half nobottommargin hidden-xs">
				<p class="nobottommargin"><strong>Llamanos:</strong> 1800-547-2145 | <strong>Email:</strong> ejemplo@email.com</p>
			</div>

			<div class="col_half col_last fright nobottommargin">

				<div class="top-links">
					<ul class="nav nav-pills top-right">
           				<li class="dropdown">
              				<div class="divisa-block">
            					<button type="button" class="btn btn-link dropdown-toggle boton-top" data-toggle="dropdown">Divisa <span class="caret"></span>
            					</button>
              
           						<ul class="dropdown-menu">
         	    					<li><a href="#">COP</a></li>
             						<li><a href="#">USD</a></li>
           						</ul>
             				</div>
           				</li>
					
						<li><a href="login.php" class="sf-with-ul"><i class="acc-closed icon-lock3"></i> Acceder</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
